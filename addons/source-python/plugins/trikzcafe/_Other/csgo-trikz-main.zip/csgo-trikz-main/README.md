# csgo-trikz
csgo trikz plugins, strippers, etc.

Converted trikz plugins from smesh292 to CS:GO. 
This is a modified version of hitbox, gravity, and flash boost to make the difficulty easier than CS:S.
It's still unstable and lots of bugs, but it doesn't affect gameplay.
I'm can only make and edit a little code, Hopefully a good coder interested in CS:GO Trikz will improve these plugins.
If you need a CS:GO trikz maps, please contact me. https://steamcommunity.com/id/ultrashim/

Server preview - steam://connect/gosev.iptime.org:13579

<b>Special Thanks to</b>

Phoenix, Flippy, Muffin, Lilly, Ekr, Kien, rr11
